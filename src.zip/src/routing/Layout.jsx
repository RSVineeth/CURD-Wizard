import React from 'react'
import { Link,Outlet } from 'react-router-dom'
const Layout = () => {
  return (
    <main>
        <div>
            <ul>
                <li>
                    <Link to='/'>Create User</Link>
                </li>
                <li>
                    <Link to='/datausers'>Users</Link>
                </li>
            </ul>
        </div>
        <hr />
        <Outlet/>
    </main>
  )
}

export default Layout