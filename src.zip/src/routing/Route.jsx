import { createBrowserRouter } from "react-router-dom";
import Layout from "./Layout";
import CreateUsers from '../crud/CreateUser'
import EditUsers from '../crud/EditUser'
import Users from '../crud/Users'
import NotFound from '../crud/NotFound'

export const router = createBrowserRouter([
    {
        path:'/',
        element:<Layout/>,
        children: [
            {
                path: '/',
                element: <CreateUsers/>
            },
            {
                path: '/EditUser',
                element: <EditUsers/>
            },
            {
                path: '/datausers',
                element: <Users/>
            },
            {
                path: '*',
                element: <NotFound/>
            }
        ]
    }
])