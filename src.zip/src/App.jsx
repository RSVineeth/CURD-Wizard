import React from 'react'
import NavBar from './crud/NavBar'
import './global.css'
import { RouterProvider, router } from 'react-router-dom'
const App = () => {
  return (
    <>
        <NavBar/>
        {/* <RouterProvider router={router}></RouterProvider> */}
    </>
  )
}

export default App