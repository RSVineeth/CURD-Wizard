import React from 'react'

const CreateUser = () => {
  return (
    <div>CreateUser</div>
  )
}

export default CreateUser