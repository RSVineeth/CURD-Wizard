import React from 'react'

const NavBar = () => {
  return (
    <nav className='navbar'>
        <p>
            <span className='crud'>Crud</span>
            <span className='operation'>Operation</span>
        </p>
    </nav>
  )
}

export default NavBar